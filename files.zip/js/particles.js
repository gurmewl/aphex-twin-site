import { throttle, isReducedMotion, getRandomNumber } from './utils.js';

class ParticleSystem {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        this.particles = [];
        this.isAnimating = false;
        this.frameId = null;
        
        this.init();
        this.bindEvents();
    }
    
    init() {
        this.resizeCanvas();
        this.createParticles();
        
        // Start animation if reduced motion is not preferred
        if (!isReducedMotion()) {
            this.start();
        }
    }
    
    bindEvents() {
        // Throttled resize handler
        window.addEventListener('resize', throttle(() => {
            this.resizeCanvas();
            this.createParticles();
        }, 250));
        
        // Handle visibility change
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                this.stop();
            } else if (!isReducedMotion()) {
                this.start();
            }
        });
    }
    
    resizeCanvas() {
        const dpr = window.devicePixelRatio || 1;
        this.canvas.width = window.innerWidth * dpr;
        this.canvas.height = window.innerHeight * dpr;
        this.canvas.style.width = `${window.innerWidth}px`;
        this.canvas.style.height = `${window.innerHeight}px`;
        this.ctx.scale(dpr, dpr);
    }
    
    createParticles() {
        const particleCount = Math.min(80, (this.canvas.width * this.canvas.height) / 20000);
        this.particles = Array.from({ length: particleCount }, () => ({
            x: getRandomNumber(0, this.canvas.width),
            y: getRandomNumber(0, this.canvas.height),
            radius: getRandomNumber(0.5, 1.5),
            dx: getRandomNumber(-0.5, 0.5),
            dy: getRandomNumber(-0.5, 0.5),
            opacity: getRandomNumber(0.1, 0.3)
        }));
    }
    
    animate() {
        if (!this.isAnimating) return;
        
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        this.particles.forEach(particle => {
            this.ctx.beginPath();
            this.ctx.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
            this.ctx.fillStyle = `rgba(111, 255, 233, ${particle.opacity})`;
            this.ctx.fill();
            
            // Update position
            particle.x += particle.dx;
            particle.y += particle.dy;
            
            // Bounce off edges
            if (particle.x < 0 || particle.x > this.canvas.width) particle.dx *= -1;
            if (particle.y < 0 || particle.y > this.canvas.height) particle.dy *= -1;
        });
        
        this.frameId = requestAnimationFrame(() => this.animate());
    }
    
    start() {
        if (this.isAnimating) return;
        this.isAnimating = true;
        this.animate();
    }
    
    stop() {
        this.isAnimating = false;
        if (this.frameId) {
            cancelAnimationFrame(this.frameId);
            this.frameId = null;
        }
    }
}

// Initialize particle system
const particles = new ParticleSystem('particles-bg');

export default particles;