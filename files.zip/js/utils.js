// Utility functions for the application
export const debounce = (func, wait) => {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
};

export const throttle = (func, limit) => {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
};

export const isReducedMotion = () => 
    window.matchMedia('(prefers-reduced-motion: reduce)').matches;

export const getRandomNumber = (min, max) => 
    Math.random() * (max - min) + min;

export const clamp = (num, min, max) => 
    Math.min(Math.max(num, min), max);