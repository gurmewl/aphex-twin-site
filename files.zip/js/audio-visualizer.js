class AudioVisualizer {
    constructor(audioId, visualizerId) {
        this.audio = document.getElementById(audioId);
        this.container = document.getElementById(visualizerId);
        this.canvas = document.createElement('canvas');
        this.ctx = this.canvas.getContext('2d');
        this.audioContext = null;
        this.analyser = null;
        this.dataArray = null;
        this.isPlaying = false;
        this.animationId = null;
        
        this.init();
    }
    
    async init() {
        try {
            this.container.appendChild(this.canvas);
            this.resizeCanvas();
            
            // Initialize audio context on user interaction
            this.audio.addEventListener('play', () => this.setupAudioContext());
            this.audio.addEventListener('pause', () => this.stop());
            this.audio.addEventListener('ended', () => this.stop());
            
            // Handle errors
            this.audio.addEventListener('error', (e) => {
                console.error('Audio error:', e);
                this.container.innerHTML = '<p>Error loading audio. Please try again later.</p>';
            });
            
            window.addEventListener('resize', () => this.resizeCanvas());
        } catch (error) {
            console.error('Visualizer initialization error:', error);
        }
    }
    
    async setupAudioContext() {
        if (!this.audioContext) {
            try {
                this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
                this.analyser = this.audioContext.createAnalyser();
                const source = this.audioContext.createMediaElementSource(this.audio);
                
                source.connect(this.analyser);
                this.analyser.connect(this.audioContext.destination);
                
                this.analyser.fftSize = 256;
                const bufferLength = this.analyser.frequencyBinCount;
                this.dataArray = new Uint8Array(bufferLength);
            } catch (error) {
                console.error('Audio context setup error:', error);
                return;
            }
        }
        
        if (this.audioContext.state === 'suspended') {
            await this.audioContext.resume();
        }
        
        this.start();
    }
    
    resizeCanvas() {
        this.canvas.width = this.container.clientWidth;
        this.canvas.height = this.container.clientHeight;
    }
    
    draw() {
        if (!this.isPlaying) return;
        
        this.animationId = requestAnimationFrame(() => this.draw());
        
        this.analyser.getByteFrequencyData(this.dataArray);
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        const barWidth = (this.canvas.width / this.dataArray.length) * 2.5;
        let x = 0;
        
        for (let i = 0; i < this.dataArray.length; i++) {
            const barHeight = (this.dataArray[i] / 255) * this.canvas.height;
            
            // Create gradient
            const gradient = this.ctx.createLinearGradient(0, this.canvas.height, 0, this.canvas.height - barHeight);
            gradient.addColorStop(0, 'rgba(111, 255, 233, 0.2)');
            gradient.addColorStop(1, 'rgba(111, 255, 233, 0.8)');
            
            this.ctx.fillStyle = gradient;
            this.ctx.fillRect(x, this.canvas.height - barHeight, barWidth, barHeight);
            
            x += barWidth + 1;
        }
    }
    
    start() {
        this.isPlaying = true;
        this.draw();
    }
    
    stop() {
        this.isPlaying = false;
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
            this.animationId = null;
        }
    }
}

// Create visualizers for each audio element
const visualizers = [
    new AudioVisualizer('audio-xtal', 'visualizer-xtal'),
    new AudioVisualizer('audio-alberto', 'visualizer-alberto')
];

// Ensure only one audio plays at a time
document.querySelectorAll('audio').forEach(audio => {
    audio.addEventListener('play', () => {
        document.querySelectorAll('audio').forEach(otherAudio => {
            if (otherAudio !== audio && !otherAudio.paused) {
                otherAudio.pause();
            }
        });
    });
});

export default visualizers;